import {
  RouterProvider,
  createRouter,
} from "@tanstack/react-router";

import { Route as RootRoute } from "./routes/__root";
import { Route as IndexRoute } from "./routes/index";
import { Route as ArchiveRoute } from "./routes/archive";

const routeTree = RootRoute.addChildren([
  IndexRoute,
  ArchiveRoute,
]);

const router = createRouter({
  routeTree,
});

export default function App() {
  return <RouterProvider router={router} />;
}